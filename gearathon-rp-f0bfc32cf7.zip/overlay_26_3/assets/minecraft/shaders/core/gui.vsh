#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the Gearathon HUD (biome bible, "Menus and GUI" > "The HUD"): the hotbar items' durability and
// cooldown bars follow their slots to the right edge. The mapping matches core/position_tex_color.vsh; keep them in
// step. No #include: vanilla notes this program is used during startup.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;

// Bars and cooldown shades lie inside a slot's item square: x from L + 3 + 20 j to + 16, y from H - 19 to H - 3.
vec2 gearHotbarFill(vec2 p) {
    vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
    float L = floor(sz.x * 0.5) - 91.0, H = sz.y;
    float X = sz.x - 28.0, Y = floor((H - 182.0) * 0.5);
    float u = p.x - L;
    if (p.y < H - 19.05 || p.y > H - 2.95) return p;
    vec2 toOff = vec2(X, Y + 185.0 - (H - 23.0));
    if (u >= -26.05 && u <= -9.95) return p + vec2(toOff.x - (L - 29.0), toOff.y);
    if (u >= 191.95 && u <= 208.05) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    float j = floor((u - 2.0) / 20.0);
    float k = u - 3.0 - 20.0 * j;
    if (j < 0.0 || j > 8.0 || k < -0.05 || k > 16.05) return p;
    return p + vec2(X - L - 20.0 * j, Y + 20.0 * j - (H - 22.0));
}

// Only the bars' own colours move: durability bars are fully opaque, the cooldown shade is white at half alpha. Chat
// and command backgrounds are see-through black: the corner of the chat's error box used to land in an item square
// and stretch that box into a long dark line up to the hotbar (3fod's screenshots, 2026-11-23).
bool gearBarColor(vec4 c) {
    return c.a > 0.99 || (all(greaterThan(c.rgb, vec3(0.99))) && abs(c.a - 0.5) < 0.03);
}

void main() {
    vec4 p = ModelViewMat * vec4(Position, 1.0);
    if (ProjMat[2][3] == 0.0 && gearBarColor(Color)) p.xy = gearHotbarFill(p.xy);
    gl_Position = ProjMat * p;

    vertexColor = Color;
}
