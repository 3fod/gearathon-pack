#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

// Bloom source for the volcanic crags: only lava-coloured bright pixels, scaled by how volcanic the camera's spot is.
// The two box_blur passes after this spread it into a glow; post/biome adds it back. The probe cells (bottom-left
// strip, see post/biome) are skipped.

uniform sampler2D InSampler;
uniform sampler2D BiomesSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const vec2 ORIGIN = vec2(0.0, 8000.0);   // world x/z of plot block (0, 0)
const float PLOT = 1001.0;

void main() {
    vec3 cam = vec3(CameraBlockPos) - CameraOffset;
    vec2 p = clamp((cam.xz - ORIGIN + 0.5) / PLOT, 0.5 / 256.0, 1.0 - 0.5 / 256.0);
    float wv = texture(BiomesSampler, vec2(p.x / 3.0, p.y)).b;
    vec3 c = texture(InSampler, texCoord).rgb;
    float hot = smoothstep(0.6, 0.95, c.r) * smoothstep(0.15, 0.45, c.r - c.b) * step(c.b, c.g + 0.08);
    vec2 px = texCoord * OutSize;
    float ch = OutSize.y / 512.0 + 1.0;
    if (px.x < 16.0 * OutSize.x / 512.0 + 1.0 && (px.y < ch || px.y > OutSize.y - ch)) hot = 0.0;
    fragColor = vec4(c * hot * wv, 1.0);
}
