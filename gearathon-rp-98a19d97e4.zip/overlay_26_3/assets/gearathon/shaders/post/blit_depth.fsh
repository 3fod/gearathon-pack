#version 330
#extension GL_ARB_separate_shader_objects : require

// Copy back into main with main's own depth (a pass that renders into a target also writes depth).

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    fragColor = vec4(texture(InSampler, texCoord).rgb, 1.0);
    gl_FragDepth = texture(DepthSampler, texCoord).r;
}
