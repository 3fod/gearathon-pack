#ifndef GEAR_SKIN_GLSL
#define GEAR_SKIN_GLSL

// Gearathon: the forge's working body (biome bible, "Forging" > "The working body"; plot code rp/forge_body.py).
// Ported from FodBall's ragdoll.glsl (same author's project); only the lighting differs: the brightness carries the part
// number, so a part is lit as daylight in the open (sky 15, dims at night), no block light.

// Body-part skins. A player's animated body is 7 item displays, each holding the player's
// own head (so the game loads their skin). Plot code scales each head into a body part and marks it with its display
// brightness: block light 15 and sky light = part id (1 head, 2 body right half, 3 body left half, 4 right arm, 5 left
// arm, 6 right leg, 7 left leg).
//
// The vertex shader (gear_part) only finds those vertices: it passes the part id on (a flat varying), lights them (see above) and leaves the head's texture coordinates alone. The fragment shader (gear_part_uv, needs GEAR_SKIN_PARTS
// defined and Sampler0 declared before the include) moves every pixel from the head's area of the skin to the part's.
// Per pixel, the interpolated head coordinate says which face (and which layer) the pixel is on without any doubt;
// per vertex, a corner on x = 32 could be the base layer's back face or the hat's right face, and telling them apart
// needed the corner's index inside its quad (gl_VertexIndex % 4), which breaks whenever a draw doesn't start on a
// multiple of 4 vertices (the stretched, wrongly coloured parts).
//
// Slim (Alex) skins have 3 pixel wide arms. Minecraft fills a skin's unused base-layer pixels with opaque black when it
// loads it (they can't be transparent: it forces the base layer opaque), and a slim skin leaves its arms' 4th column
// unused: so a skin whose right arm (x 54-55, y 20-31) and left arm (x 46-47, y 52-63) are black there is slim. Its
// arms read the 3-wide layout, stretched over the 4 pixel wide arm (plot code can't know the skin's model to make the
// arm narrower), so no black stripes show.
//
// How the mapping works: a cube's faces are unfolded on the skin the same way for every body part (top/bottom in a
// top row, then right/front/left/back), so the head's grid cells x = 0, 8, 16, 24, 32 and y = 0, 8, 16 map one to
// one onto the part's cells. The hat layer (x + 32) maps onto the part's overlay layer (sleeves, jacket, pants). The
// body is 8 wide but only 4 deep, which that grid can't express, so it is drawn as two 4x12x4 halves.

/** The body part (1-7) a vertex belongs to, or 0. Body parts are lit full bright. */
int gear_part(inout ivec2 light, vec2 uv) {
    int block = light.x / 16;
    int sky = light.y / 16;
    if (block != 15 || sky < 1 || sky > 7) return 0;
    vec2 px = uv * 64.0;
    // a head only uses the top quarter of the skin
    if (px.x > 64.5 || px.y > 16.5) return 0;
    light = ivec2(0, 240);     // sky light only (round 5, 3fod: "why is the body so bright?": block light 6, lifted by
                               // the Brightness slider, made it glow at night while the furnace beside it was dark)
    return sky;
}

#ifdef GEAR_SKIN_PARTS

/** Is this skin pixel the black Minecraft fills unused base-layer pixels with? */
bool gear_unused_px(vec2 p) {
    vec4 c = textureLod(Sampler0, (p + 0.5) / 64.0, 0.0);
    return c.r + c.g + c.b < 0.03;
}

/** Is the skin bound for this part a slim (Alex) one? Both arms' 4th column is unused (black) */
bool gear_slim_skin() {
    return gear_unused_px(vec2(54.0, 20.0)) && gear_unused_px(vec2(55.0, 25.0)) && gear_unused_px(vec2(54.0, 31.0))
        && gear_unused_px(vec2(46.0, 52.0)) && gear_unused_px(vec2(47.0, 57.0)) && gear_unused_px(vec2(46.0, 63.0));
}

// side-row grid x (5 values), the top row's x = 24 (bottom face's far edge), grid y (3 values), overlay offset
void gear_part_table(int part, bool slim, out float xs[5], out float top24, out float ys[3], out vec2 overlay) {
    if (part == 1) { // head
        xs = float[5](0.0, 8.0, 16.0, 24.0, 32.0); top24 = 24.0; ys = float[3](0.0, 8.0, 16.0); overlay = vec2(32.0, 0.0);
    } else if (part == 2) { // body, player's right half (front left half of the texture, back right half)
        xs = float[5](16.0, 20.0, 24.0, 36.0, 40.0); top24 = 32.0; ys = float[3](16.0, 20.0, 32.0); overlay = vec2(0.0, 16.0);
    } else if (part == 3) { // body, player's left half
        xs = float[5](20.0, 24.0, 28.0, 32.0, 36.0); top24 = 36.0; ys = float[3](16.0, 20.0, 32.0); overlay = vec2(0.0, 16.0);
    } else if (part == 4 && slim) { // right arm, 3 wide
        xs = float[5](40.0, 44.0, 47.0, 51.0, 54.0); top24 = 50.0; ys = float[3](16.0, 20.0, 32.0); overlay = vec2(0.0, 16.0);
    } else if (part == 4) { // right arm
        xs = float[5](40.0, 44.0, 48.0, 52.0, 56.0); top24 = 52.0; ys = float[3](16.0, 20.0, 32.0); overlay = vec2(0.0, 16.0);
    } else if (part == 5 && slim) { // left arm, 3 wide
        xs = float[5](32.0, 36.0, 39.0, 43.0, 46.0); top24 = 42.0; ys = float[3](48.0, 52.0, 64.0); overlay = vec2(16.0, 0.0);
    } else if (part == 5) { // left arm
        xs = float[5](32.0, 36.0, 40.0, 44.0, 48.0); top24 = 44.0; ys = float[3](48.0, 52.0, 64.0); overlay = vec2(16.0, 0.0);
    } else if (part == 6) { // right leg
        xs = float[5](0.0, 4.0, 8.0, 12.0, 16.0); top24 = 12.0; ys = float[3](16.0, 20.0, 32.0); overlay = vec2(0.0, 16.0);
    } else { // left leg
        xs = float[5](16.0, 20.0, 24.0, 28.0, 32.0); top24 = 28.0; ys = float[3](48.0, 52.0, 64.0); overlay = vec2(-16.0, 0.0);
    }
}

/** A body part pixel's skin coordinates, from the head coordinates interpolated across its face */
vec2 gear_part_uv(int part, vec2 uv) {
    vec2 px = uv * 64.0;
    bool hat = px.x >= 32.0;
    if (hat) px.x -= 32.0;

    float xs[5];
    float top24;
    float ys[3];
    vec2 overlay;
    bool slim = (part == 4 || part == 5) && gear_slim_skin();
    gear_part_table(part, slim, xs, top24, ys, overlay);

    // the face's cell and where in it the pixel is (kept off the cell's edges so it never samples a neighbour)
    int gx = clamp(int(floor(px.x / 8.0)), 0, 3);
    int row = px.y < 8.0 ? 0 : 1;
    vec2 f = clamp((px - vec2(float(gx) * 8.0, float(row) * 8.0)) / 8.0, 0.001, 0.999);
    float x0 = xs[gx];
    float x1 = xs[gx + 1];
    if (row == 0 && gx == 2) x1 = top24; // the bottom face
    vec2 q = vec2(mix(x0, x1, f.x), mix(ys[row], ys[row + 1], f.y));
    if (hat) q += overlay;
    return q / 64.0;
}

#endif

#endif
