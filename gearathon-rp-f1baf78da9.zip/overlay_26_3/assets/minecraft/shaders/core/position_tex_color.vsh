#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the Gearathon HUD's hotbar move (biome bible, "Menus and GUI" > "The HUD"): the game still
// draws its own hotbar at the bottom centre, and this stands it up along the right edge. The same mapping is in
// core/text.vsh (item counts) and core/gui.vsh (durability and cooldown bars), and rp/hud.py mirrors it in Python
// for the preview. Keep the four in step.
//
// No #include here: vanilla notes this program is used during startup, before resource packs exist.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;

bool gearNear(float a, float b) { return abs(a - b) < 0.05; }

// Vanilla's hotbar in GUI pixels: hotbar sprite 182 x 22 at (L, H - 22); selection 24 x 23 at (L - 1 + 20 s, H - 23);
// slot j's item 16 x 16 at (L + 3 + 20 j, H - 19); off-hand sprite 29 x 24 at (L - 29, H - 23) (left) or (L + 182,
// H - 23) (right), its item 3 px in. L = floor(width / 2) - 91.
// Ours: the strip 22 wide x 182 tall at (X, Y), X = width - 28, Y centred; the hotbar's u axis runs down it. The
// off-hand box (the backpack slot) 22 x 23 at (X, Y + 186).
vec2 gearHotbar(vec2 p) {
    vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
    float L = floor(sz.x * 0.5) - 91.0, H = sz.y;
    float X = sz.x - 28.0, Y = floor((H - 182.0) * 0.5);
    float u = p.x - L, v = p.y - (H - 22.0);
    // hotbar and selection sprites: turned 90 degrees, top edge to the right (keeps the winding)
    float m = mod(u + 1.0, 20.0);
    bool bar = (gearNear(u, 0.0) || gearNear(u, 182.0)) && (gearNear(p.y, H - 22.0) || gearNear(p.y, H));
    bool sel = (gearNear(m, 0.0) || gearNear(m, 20.0) || gearNear(m, 4.0)) && u > -1.5 && u < 183.5
               && (gearNear(p.y, H - 23.0) || gearNear(p.y, H));
    if (bar || sel) return vec2(X + 22.0 - v, Y + u);
    // off-hand sprites (the backpack slot, rp/inv_art.py), moved under the strip: 4 px gap, left edges lined up
    bool offRow = gearNear(p.y, H - 23.0) || gearNear(p.y, H + 1.0);
    vec2 toOff = vec2(X, Y + 185.0 - (H - 23.0));
    if (offRow && (gearNear(u, -29.0) || gearNear(u, 0.0))) return p + vec2(toOff.x - (L - 29.0), toOff.y);
    if (offRow && (gearNear(u, 182.0) || gearNear(u, 211.0))) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    // item icons: moved into their cell, not turned
    if (gearNear(p.y, H - 19.0) || gearNear(p.y, H - 3.0)) {
        float k = mod(u - 3.0, 20.0);
        if ((gearNear(k, 0.0) || gearNear(k, 20.0) || gearNear(k, 16.0)) && u > 0.0 && u < 182.0) {
            float j = floor(u / 20.0);
            return p + vec2(X - L - 20.0 * j, Y + 20.0 * j - (H - 22.0));
        }
        if (gearNear(u, -26.0) || gearNear(u, -10.0)) return p + vec2(toOff.x - (L - 29.0), toOff.y);
        if (gearNear(u, 192.0) || gearNear(u, 208.0)) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    }
    // vanilla's status effect icons (18 x 18 at (W - 25 k + 3, 4) or (.., 30)): hidden, the HUD draws its own badges
    // (text HUD, core/text.vsh). Their backgrounds are transparent sprites (rp/hud.py HIDDEN).
    float e = sz.x - p.x, em = mod(e, 25.0);
    bool eRow = gearNear(p.y, 4.0) || gearNear(p.y, 22.0) || gearNear(p.y, 30.0) || gearNear(p.y, 48.0);
    if (eRow && e > 3.5 && e < 500.0 && (gearNear(em, 22.0) || gearNear(em, 4.0))) return vec2(-1.0e4);
    return p;
}

// The backpack (biome bible, "The backpack"): position relative to the hover squares of a 6-row chest menu's 27 main
// slots (24 x 24 at slot - 4). position_tex_color.fsh drops the hover sprite's pixels there, per pixel: moving single
// corners here stretched any other sprite whose corner happened to land on that grid (tooltips, option widgets).
layout(location = 2) out vec2 gearRel;

// The stripped inventory screen (biome bible, "The backpack" > "The inventory screen (E)"): 176 x 166, centred. The
// hover square of a hidden slot is dropped: gearHide is 1 at a vertex that lies on the hover grid of one of those
// slots (24 x 24 at slot - 4, nine-slice border 4: x and y in {s - 4, s, s + 16, s + 20}), so it is 1 all over a quad
// only when all four corners do; position_tex_color.fsh also needs the highlight's marker alpha. Hidden: the 27 main
// slots (incl. the 4 of the big backpack slot), the off hand and the 2 x 2 crafting grid. Left alone, because their
// hover pieces coincide with the backpack menu's: the armour column (its first column) and the crafting result (the
// bottom-right corner piece of its cell 8 of row 2).
layout(location = 3) out float gearHide;

bool gearOnGrid(float d) { return gearNear(d, -4.0) || gearNear(d, 0.0) || gearNear(d, 16.0) || gearNear(d, 20.0); }

bool gearSlotGrid(vec2 r, vec2 s) { return gearOnGrid(r.x - s.x) && gearOnGrid(r.y - s.y); }

float gearInvHide(vec2 p, vec2 sz) {
    vec2 r = p - floor((sz - vec2(176.0, 166.0)) * 0.5);
    // round 5: the off-hand item (the backpack slot's picture) is dropped whole on this screen: a quad with all four
    // corners on its 16 x 16 square gets 2 (position_tex_color.fsh drops it whatever its alpha)
    if ((gearNear(r.x, 77.0) || gearNear(r.x, 93.0)) && (gearNear(r.y, 62.0) || gearNear(r.y, 78.0))) return 2.0;
    for (int row = 0; row < 3; row++) {                        // main slots: x 8 + 18 c, y 84 + 18 row
        float dy = r.y - 84.0 - 18.0 * float(row);
        if (gearOnGrid(dy)) {
            float c = floor((r.x - 8.0 + 4.5) / 18.0);
            for (int k = -1; k <= 1; k++) {
                float cc = c + float(k);
                if (cc >= 0.0 && cc <= 8.0 && gearOnGrid(r.x - 8.0 - 18.0 * cc)) return 1.0;
            }
        }
    }
    if (gearSlotGrid(r, vec2(77.0, 62.0))) return 1.0;                                         // off hand
    for (int i = 0; i < 4; i++)                                                                 // crafting grid
        if (gearSlotGrid(r, vec2(98.0 + 18.0 * float(i % 2), 18.0 + 18.0 * float(i / 2)))) return 1.0;
    return 0.0;
}

// Round 5 (biome bible, "The inventory screen (E)", round 5): the player model is rendered into its own texture and
// drawn as one quad at (26, 8)-(75, 78) of the 176 x 166 screen, with UVs (0, 1) top-left, (0, 0) bottom-left,
// (1, 0) bottom-right, (1, 1) top-right. A vertex is moved only when it sits exactly on one of those corners with that
// UV, so no other sprite can match; the quad goes to (118, 65)-(167, 135) (rp/inv_art.py MODEL_TO).
vec2 gearModel(vec2 p, vec2 sz) {
    vec2 r = p - floor((sz - vec2(176.0, 166.0)) * 0.5);
    bool L = gearNear(r.x, 26.0), R = gearNear(r.x, 75.0), T = gearNear(r.y, 8.0), B = gearNear(r.y, 78.0);
    if (!((L || R) && (T || B))) return p;
    vec2 uv = vec2(R ? 1.0 : 0.0, T ? 1.0 : 0.0);
    if (any(greaterThan(abs(UV0 - uv), vec2(1.0e-4)))) return p;
    return p + vec2(92.0, 57.0);
}

void main() {
    vec4 p = ModelViewMat * vec4(Position, 1.0);
    gearRel = vec2(-1.0e4);
    gearHide = 0.0;
    if (ProjMat[2][3] == 0.0) {                        // orthographic: the GUI
        vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
        gearHide = gearInvHide(p.xy, sz);
        p.xy = gearModel(p.xy, sz);
        gearRel = p.xy - floor((sz - vec2(176.0, 222.0)) * 0.5) - vec2(4.0, 136.0);
        p.xy = gearHotbar(p.xy);
    }
    gl_Position = ProjMat * p;

    texCoord0 = UV0;
    vertexColor = Color;
}
