#version 330
#extension GL_ARB_separate_shader_objects : require
#include <minecraft:globals.glsl>

// Bloom source for the volcanic crags: only lava-coloured bright pixels, scaled by how volcanic the camera's spot is.
// The two box_blur passes after this spread it into a glow; post/biome adds it back. The probe cells (bottom-left
// strip, see post/biome) are skipped.

uniform sampler2D InSampler;
uniform sampler2D BiomesSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const ivec2 ORIGIN_FALLBACK = ivec2(0, 8000);   // world x/z of plot block (0, 0) when the probe gives none
const float PLOT = 1001.0;

bool isMarker(vec3 c) { return all(lessThan(abs(c * 255.0 - vec3(165.0, 90.0, 195.0)), vec3(0.5))); }

void main() {
    // the plot's world origin from the probe strip's cells 16, 17 (post/biome, core/item.vsh), else the old fixed one
    int row = 0;
    if (!isMarker(texelFetch(InSampler, ivec2(15, 0), 0).rgb)) row = int(InSize.y) - 1;
    ivec2 org = ORIGIN_FALLBACK;
    if (isMarker(texelFetch(InSampler, ivec2(15, row), 0).rgb)) {
        vec3 ox = floor(texelFetch(InSampler, ivec2(16, row), 0).rgb * 255.0 + 0.5);
        vec3 oz = floor(texelFetch(InSampler, ivec2(17, row), 0).rgb * 255.0 + 0.5);
        if (ox.r + ox.g + ox.b > 0.0 && oz.r + oz.g + oz.b > 0.0)
            org = ivec2(int(ox.r * 65536.0 + ox.g * 256.0 + ox.b) - 8388608, int(oz.r * 65536.0 + oz.g * 256.0 + oz.b) - 8388608) * 16;
    }
    vec3 cam = vec3(CameraBlockPos - ivec3(org.x, 0, org.y)) - CameraOffset;
    vec2 p = clamp((cam.xz + 0.5) / PLOT, 0.5 / 256.0, 1.0 - 0.5 / 256.0);
    float wv = texture(BiomesSampler, vec2(p.x / 3.0, p.y)).b;
    vec3 c = texture(InSampler, texCoord).rgb;
    float hot = smoothstep(0.6, 0.95, c.r) * smoothstep(0.15, 0.45, c.r - c.b) * step(c.b, c.g + 0.08);
    vec2 px = texCoord * OutSize;
    float ch = OutSize.y / 512.0 + 1.0;
    if (px.x < 18.0 * OutSize.x / 512.0 + 1.0 && (px.y < ch || px.y > OutSize.y - ch)) hot = 0.0;
    fragColor = vec4(c * hot * wv, 1.0);
}
