#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:light.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <gearathon:skin.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

uniform sampler2D Sampler0;

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif
layout(location = 7) flat out float probeOn;
layout(location = 8) flat out vec3 probeCol;
layout(location = 9) flat out int gearPart;   // the forge's working body (skin.glsl), in case heads in displays draw here
layout(location = 10) flat out vec2 probeOrigin;   // the plot's world origin / 16 (x, z), or (-1e9) when unknown

// Gearathon probe (DF: a 0.001-scale item display of a stick with item_model gearathon:probe at each player's eye; the
// pattern is bodycam's verified camera marker). Its texture is two magic texels (12, 219, 77 / 78), one per face
// winding, so one face survives culling. The quad that samples one is moved to an 18 x 1 pixel strip in the bottom-left
// corner (corners from where UV0 sits inside the texel, not gl_VertexIndex), nearest depth; item.fsh writes the camera
// rotation, projection terms, sky light, fog colour and a marker there, one value per pixel. post/biome reads them.
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    ivec2 light = UV2;
    gearPart = gear_part(light, UV0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, light);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;

    probeOn = 0.0;
    probeCol = vec3(0.0);
    probeOrigin = vec2(-1.0e9);
    ivec4 mk = ivec4(texelFetch(Sampler0, ivec2(UV0 * vec2(textureSize(Sampler0, 0))), 0) * 255.0 + 0.5);
    if (mk.r == 12 && mk.g == 219 && (mk.b == 77 || mk.b == 78) && mk.a == 255) {
        vec2 f = fract(UV0 * vec2(textureSize(Sampler0, 0)));
        int c = f.x > 0.5 ? (f.y > 0.5 ? 2 : 3) : (f.y > 0.5 ? 1 : 0);
        if (mk.b == 78) c = 3 - c;
        // the plot's world origin (biome bible, "The plot's world origin"): the tint is the plot block DF moved the
        // probe to (x * 1024 + z); the probe's world position minus that, snapped to 16 (DF's plot origins are
        // multiples of 16, and that absorbs any lag between the move and the tint). Integer parts kept exact.
        vec3 tc = floor(Color.rgb * 255.0 + 0.5);
        float tv = tc.r * 65536.0 + tc.g * 256.0 + tc.b;
        if (tv < 16777214.5) {
            vec2 pp = vec2(floor(tv / 1024.0), mod(tv, 1024.0));
            vec2 o = vec2(CameraBlockPos.xz) + floor(Position.xz - CameraOffset.xz - pp + 0.5);
            probeOrigin = floor(o / 16.0 + 0.5);
        }
        vec2 hi = vec2(-1.0) + 2.0 * vec2(18.0, 1.0) / ScreenSize;
        gl_Position = vec4((c == 1 || c == 2) ? hi.x : -1.0, c >= 2 ? hi.y : -1.0, 0.9999, 1.0);   // reversed depth: nearest
        probeOn = 1.0;
    #ifndef OIT_ALPHA_ONLY
        probeCol = texture(Sampler2, vec2(0.5 / 16.0, 15.5 / 16.0)).rgb;    // sky light colour (day / night)
    #endif
    }
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif
}
