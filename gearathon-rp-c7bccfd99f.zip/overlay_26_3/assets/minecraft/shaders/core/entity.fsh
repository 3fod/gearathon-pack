#version 330
#extension GL_ARB_separate_shader_objects : require

// Gearathon override of vanilla 26.3 entity.fsh. Only change: body parts (gearPart > 0, set by entity.vsh) sample the skin at
// their body part's coordinates (gear_part_uv in gearathon/shaders/include/skin.glsl) instead of the head's.
// The viewmodel's sword (gearVm 1) is painted from the sprite in gearathon:viewmodel.glsl. Everything else is vanilla.

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#define GEAR_SKIN_PARTS
#include <gearathon:skin.glsl>
#include <gearathon:viewmodel.glsl>

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif
layout(location = 8) flat in int gearPart;
layout(location = 9) flat in int gearVm;
layout(location = 10) in vec2 gearVmSpr;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= lightMapColor;
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    // the viewmodel never covers the camera probe's 18 x 1 strip (bottom-left; top-left when flipped), which
    // post/biome reads: covered, the post effect lost its camera (white status dot, 3fod 2026-11-25)
    if (gearVm != -1 && gl_FragCoord.x < 18.0 && (gl_FragCoord.y < 1.0 || gl_FragCoord.y > ScreenSize.y - 1.0)) {
        discard;
    }
    vec4 color = texture(Sampler0, gearPart > 0 ? gear_part_uv(gearPart, texCoord0) : texCoord0);
    if (gearVm == 1) {                           // the viewmodel sword: our sprite, not the skin
        color = vm_sprite(gearVmSpr);
        if (color.a < 0.5) {
            discard;
        }
    }

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= faceVertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
