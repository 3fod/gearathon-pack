#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the Gearathon HUD (biome bible, "Menus and GUI" > "The HUD"): the hotbar items' durability and
// cooldown bars follow their slots to the right edge. The mapping matches core/position_tex_color.vsh; keep them in
// step. No #include: vanilla notes this program is used during startup.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;

// Bars and cooldown shades lie inside a slot's item square: x from L + 3 + 20 j to + 16, y from H - 19 to H - 3.
vec2 gearHotbarFill(vec2 p) {
    vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
    float L = floor(sz.x * 0.5) - 91.0, H = sz.y;
    float X = sz.x - 28.0, Y = floor((H - 182.0) * 0.5);
    float u = p.x - L;
    if (p.y < H - 19.05 || p.y > H - 2.95) return p;
    vec2 toOff = vec2(X, Y + 185.0 - (H - 23.0));
    if (u >= -26.05 && u <= -9.95) return p + vec2(toOff.x - (L - 29.0), toOff.y);
    if (u >= 191.95 && u <= 208.05) return p + vec2(toOff.x - 7.0 - (L + 182.0), toOff.y);
    float j = floor((u - 2.0) / 20.0);
    float k = u - 3.0 - 20.0 * j;
    if (j < 0.0 || j > 8.0 || k < -0.05 || k > 16.05) return p;
    return p + vec2(X - L - 20.0 * j, Y + 20.0 * j - (H - 22.0));
}

// Only the bars' own colours move: durability bars are fully opaque, the cooldown shade is white at half alpha. Chat
// and command backgrounds are see-through black: the corner of the chat's error box used to land in an item square
// and stretch that box into a long dark line up to the hotbar (3fod's screenshots, 2026-11-23).
bool gearBarColor(vec4 c) {
    return c.a > 0.99 || (all(greaterThan(c.rgb, vec3(0.99))) && abs(c.a - 0.5) < 0.03);
}

// The inventory's effect cards (biome bible, "Effects in the inventory"): the durability bar of the icon item in
// column 4 of main rows 1-3 (slot (62, 84 + 18 r) of the 176 x 166 screen; bar quads x + 2 .. x + 15, y + 13 .. y + 15)
// is stretched to the right into the card's trough (x 80 .. 101) and 2x taller, gold on dark. Only exact places of
// the bar colours match (the backpack menu's cells never sit there).
bool gearEffBar(inout vec2 p, inout vec4 c) {
    vec2 sz = floor(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) + 0.5);
    vec2 o = floor((sz - vec2(176.0, 166.0)) * 0.5), r = p - o;
    if (r.x < 63.95 || r.x > 77.05) return false;
    for (int k = 0; k < 3; k++) {
        float sy = 84.0 + 18.0 * float(k);
        if (r.y > sy + 12.95 && r.y < sy + 15.05) {
            p = o + vec2(80.0 + (r.x - 64.0) * (21.0 / 13.0), sy + 7.0 + (r.y - sy - 13.0) * 2.0);
            c = all(lessThan(c.rgb, vec3(0.05))) ? vec4(27.0, 25.0, 38.0, 255.0) / 255.0
                                                 : vec4(217.0, 160.0, 50.0, 255.0) / 255.0;
            return true;
        }
    }
    return false;
}

void main() {
    vec4 p = ModelViewMat * vec4(Position, 1.0);
    vec4 c = Color;
    if (ProjMat[2][3] == 0.0 && gearBarColor(Color) && !gearEffBar(p.xy, c)) p.xy = gearHotbarFill(p.xy);
    gl_Position = ProjMat * p;

    vertexColor = c;
}
