#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the Gearathon minimap's cut (biome bible, "The HUD" > "Minimap"); gearClip comes from core/text.vsh.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in vec3 gearClip;     // the minimap (core/text.vsh gearMap): cut to its 72 x 72 window
layout(location = 5) in vec4 gearMir;      // the backpack's spinning picture past its edge (core/text.vsh gearSpin)

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    if (gearClip.z > 0.5 && (gearClip.x < 0.0 || gearClip.y < 0.0 || gearClip.x >= 72.0 || gearClip.y >= 72.0)) {
        discard;
    }
    vec2 uv = texCoord0;
    if (gearMir.y > 1.0e-4 && gearMir.w > 1.0e-4) {              // mirror u between the glyph's left and right edges
        uv.x = gearMir.x / gearMir.y + gearMir.z / gearMir.w - uv.x;
    }
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, uv).rrrr;
    #else
    vec4 texColor = texture(Sampler0, uv);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
