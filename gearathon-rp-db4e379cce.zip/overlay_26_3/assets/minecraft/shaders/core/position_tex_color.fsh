#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 plus the backpack's hover hiding (biome bible, "The backpack"): over the 27 main slots of a 6-row chest
// menu (the locked filler under the details panel) the hover square's pixels are dropped. They are found by their
// alpha, set only in rp/bag.py highlight(): 253 (gold corners) and 33 (fill). gearRel comes from position_tex_color.vsh.

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 2) in vec2 gearRel;
layout(location = 3) in float gearHide;     // 1 all over a hover square of the inventory screen's hidden slots, 2 over the off-hand item

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    vec4 color = tex * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    float a = tex.a * 255.0;
    if (gearHide > 1.999) {                     // round 5: the off-hand item on the inventory screen
        discard;
    }
    bool marker = abs(a - 253.0) < 0.5 || abs(a - 33.0) < 0.5;
    if (marker && (gearHide > 0.999 || (gearRel.x >= 0.0 && gearRel.x < 168.0 && gearRel.y >= 0.0 && gearRel.y < 60.0))) {
        discard;
    }
    fragColor = color * ColorModulator;
}
