#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>

// Gearathon sky (rebuilt 2026-11-08; 3fod: "a lot like Bare Skies, no dithering, fake moving clouds", clouds "not
// realistic but pixelated"). The gradient is smooth: no bands, no dither. The look is measured from the Bare Skies
// pack's layers (nothing of it is shipped), composed in the same order and on the same clock:
//   base      pale periwinkle, dimmed by vanilla's day curve
//   sunrise   a purple wash low in the sky, plus a gold band added along the eastern horizon
//   day       flat saturated blue that melts into the pale base toward the horizon
//   sunset    indigo over the top of the sky, plus a peach band added along the western horizon
//   night     flat navy, tiny stars that turn with the sun (vanilla's own star pass is off: core/stars.fsh)
// Time of day: DF's clock (rp/df_env.py func.gear.sky) arrives as the cloud fog end distance, 2 .. 30 over one day. It
// was the sky colour first, but the game blends the sky colour into the fog, so the fog's tint cycled.
// Biome look: the sky sinks into FogColor at the horizon, so it meets DF's per-biome distance fog without a seam;
// thick-fog biomes (fog end < ~150) still bury the sky like vanilla.
// Clouds: flat pixel art (square pixels, hard edges, three flat tones) on a plane high above the camera, so they slide
// past as you move, and drifting with the world's wind. They repeat exactly once per GameTime wrap, so they never
// jump. Vanilla's 3D clouds are off (empty clouds.png). Shooting stars are pixel art too, in the sun and moon's colours.
// The sun and moon are vanilla's passes with our textures (rp/celestials.py), drawn after this one.

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyPos;

layout(location = 0) out vec4 fragColor;

const float TAU = 6.2831853;

const vec3 SKY_PALE   = vec3(200.0, 214.0, 255.0) / 255.0;
const vec3 SKY_BLUE   = vec3(101.0, 151.0, 254.0) / 255.0;
const vec3 SKY_PURPLE = vec3(200.0, 154.0, 229.0) / 255.0;
const vec3 SKY_GOLD   = vec3(217.0, 189.0, 128.0) / 255.0;
const vec3 SKY_INDIGO = vec3( 58.0,  55.0, 114.0) / 255.0;
const vec3 SKY_PEACH  = vec3(215.0, 142.0, 107.0) / 255.0;
const vec3 SKY_NAVY   = vec3(  0.0,  18.0,  45.0) / 255.0;

const float STAR_GRID = 64.0;                  // cells per cube face
const float STAR_CHANCE = 0.05;                // of a cell holding a star: ~200 a face, like the reference

const bool  CLOUDS_ON = true;                  // false = no painted clouds
const vec2  CLOUD_WIND = vec2(-0.932, 0.362);  // the world's wind (rp/df_env.py WIND, biome.fsh WIND)
const float CLOUD_Y = 560.0;                   // height of the painted plane (3fod: 330 looked too low)
const float CLOUD_PIXEL = 11.0;                // blocks per cloud pixel
const float CLOUD_PX_ACROSS = 8.0;             // pixels per noise cell across the wind
const float CLOUD_PX_ALONG = 10.0;             // pixels per noise cell along the wind (clouds are a bit longer that way)
const float CLOUD_PERIOD = 40.0;               // noise cells until it repeats: one repeat per 20 min GameTime wrap, so
                                               // speed = PIXEL * PX_ALONG * PERIOD / 1200 s = 3.7 blocks/s
const float CLOUD_COVER = 0.55;                // noise value where a cloud starts: lower = more sky covered

const float METEOR_GRID = 128.0;               // shooting star pixels per cube face: about a sun / moon texel each

// window on the day clock: fades in from start over rise ticks, holds, fades out over fall ticks
float gskyWindow(float tick, float start, float rise, float hold, float fall) {
    float x = mod(tick - start, 24000.0);
    return min(clamp(x / rise, 0.0, 1.0), 1.0 - clamp((x - rise - hold) / fall, 0.0, 1.0));
}

// the warm band along the horizon on the sun's side: peaks just below the horizon, half strength 90 degrees around
// the sky, nothing on the far side. sideX is +1 for the east, -1 for the west.
float gskyBand(vec3 dir, float sideX) {
    float h = dir.x * sideX / max(length(dir.xz), 1e-4);
    float v = (dir.y + 0.18) / 0.30;
    return 0.85 * exp(-v * v) * (0.5 + 0.5 * h);
}

float gskyHash(vec2 p) {
    vec3 q = fract(vec3(p.xyx) * 0.1031);
    q += dot(q, q.yzx + 33.33);
    return fract((q.x + q.y) * q.z);
}

// value noise whose lattice repeats every per cells (quintic blend, so no grid lines show)
float gskyNoise(vec2 p, float per) {
    vec2 i = floor(p), f = p - i;
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    vec2 a = mod(i, per), b = mod(i + 1.0, per);
    return mix(mix(gskyHash(a), gskyHash(vec2(b.x, a.y)), f.x),
               mix(gskyHash(vec2(a.x, b.y)), gskyHash(b), f.x), f.y);
}

// the cloud picture at m (noise cells): 3 octaves, chunky blobs with no fine detail smaller than a pixel. The warp is
// part of the picture, so the whole thing slides rigidly and pixels don't flicker.
float gskyCloudField(vec2 m) {
    float per = CLOUD_PERIOD * 0.6;
    m += (vec2(gskyNoise(m * 0.6 + vec2(3.0, 7.0), per), gskyNoise(m * 0.6 + vec2(11.0, 2.0), per)) - 0.5) * 0.6;
    float s = 0.0, a = 0.5, n = 0.0;
    per = CLOUD_PERIOD;
    for (int i = 0; i < 3; i++) {
        s += a * gskyNoise(m + float(i) * 17.0, per);
        n += a;
        m *= 2.0;
        per *= 2.0;
        a *= 0.5;
    }
    return s / n;
}

// the centre of the grid cell this direction falls in, on a cube around the camera
vec3 gskySnap(vec3 d) {
    vec3 a = abs(d);
    float m = max(a.x, max(a.y, a.z));
    vec3 q = (floor(d / m * METEOR_GRID * 0.5) + 0.5) / (METEOR_GRID * 0.5);
    if (m == a.x) q.x = sign(d.x);
    else if (m == a.y) q.y = sign(d.y);
    else q.z = sign(d.z);
    return normalize(q);
}

// tiny soft dots, 1-3 pixels wide, on the unit direction s; px = one screen pixel in radians
float gskyStars(vec3 s, float px) {
    vec3 a = abs(s);
    float m = max(a.x, max(a.y, a.z));
    vec2 uv;
    float face;
    if (m == a.x) { uv = s.yz / m; face = s.x > 0.0 ? 1.0 : 2.0; }
    else if (m == a.y) { uv = s.xz / m; face = s.y > 0.0 ? 3.0 : 4.0; }
    else { uv = s.xy / m; face = s.z > 0.0 ? 5.0 : 6.0; }
    vec2 g = (uv * 0.5 + 0.5) * STAR_GRID;
    vec2 id = floor(g), f = g - id;
    vec2 seed = id + face * 97.0;
    if (gskyHash(seed) > STAR_CHANCE) return 0.0;
    float h = gskyHash(seed + 41.3);
    vec2 centre = 0.2 + 0.6 * vec2(gskyHash(seed + 7.1), gskyHash(seed + 19.9));
    float d = length(f - centre) * 2.0 / STAR_GRID * m;
    float r = (h < 0.33 ? 1.5 : 0.85) * px;
    float bright = 0.55 + 0.45 * fract(h * 37.0);
    float twinkle = 0.85 + 0.15 * sin(TAU * GameTime * (240.0 + floor(h * 300.0)) + h * 50.0);
    return (1.0 - smoothstep(r * 0.35, r + px * 0.5, d)) * bright * twinkle;
}

// shooting stars in the sun and moon's pixel style: a cream head with one dim ring of glow and a tail that steps down
// through gold and peach. Every cell is flat. Up to two streams, each a meteor in ~45% of its slots, sliding downward.
vec3 gskyMeteors(vec3 dir, float t) {
    vec3 p = gskySnap(dir);
    float cell = 2.0 / METEOR_GRID;
    vec3 sum = vec3(0.0);
    for (int n = 0; n < 2; n++) {
        float len = n == 0 ? 7.0 : 11.0;
        float tt = t + float(n) * 3.1;
        float slot = floor(tt / len), ph = tt - slot * len;
        vec2 sd = vec2(slot, float(n) * 5.0 + 1.0);
        float life = 0.7 + 0.5 * gskyHash(sd + 2.5);
        if (gskyHash(sd + 0.5) > 0.45 || ph > life) continue;
        vec3 start = normalize(vec3(gskyHash(sd + 3.5) * 2.0 - 1.0, 0.35 + 0.55 * gskyHash(sd + 4.5), gskyHash(sd + 5.5) * 2.0 - 1.0));
        vec3 along = normalize(cross(start, normalize(vec3(gskyHash(sd + 6.5) - 0.5, 0.2, gskyHash(sd + 7.5) - 0.5))));
        if (along.y > 0.0) along = -along;
        float k = ph / life;
        float headAt = (0.45 + 0.25 * gskyHash(sd + 8.5)) * k;
        vec3 head = normalize(start + along * headAt);
        if (dot(p, head) < 0.9) continue;
        vec3 tail = normalize(start + along * max(headAt - 0.24, 0.0));
        vec3 ba = head - tail, pa = p - tail;
        float s = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-7), 0.0, 1.0);
        float toLine = length(pa - ba * s), toHead = length(p - head);
        vec3 col = vec3(0.0);
        if (toHead < cell * 1.2) col = vec3(1.0, 0.99, 0.84);
        else if (toLine < cell * 0.62) col = s > 0.66 ? SKY_GOLD : s > 0.33 ? SKY_PEACH * 0.8 : SKY_PEACH * 0.42;
        else if (toHead < cell * 2.3) col = vec3(0.34, 0.26, 0.16);
        sum += col * clamp(ceil(min(k / 0.12, (1.0 - k) / 0.3) * 3.0) / 3.0, 0.0, 1.0);    // appears and fades in 3 steps
    }
    return sum;
}

void main() {
    vec3 dir = normalize(skyPos);
    float up = max(dir.y, 0.0);
    float px = length(fwidth(dir)) * 0.6;                               // one screen pixel, in radians
    float t = GameTime * 1200.0;                                        // seconds

    // time of day: DF's clock in the cloud fog end distance (clouds are painted here, so nothing else reads it). It is
    // capped by the player's cloud distance, at least 32 blocks, so the range stays below that.
    bool clk = FogCloudsEnd >= 1.9 && FogCloudsEnd <= 30.1;
    float tick = clk ? clamp((FogCloudsEnd - 2.0) / 28.0, 0.0, 1.0) * 24000.0 : (ColorModulator.b > 0.5 ? 6000.0 : 18000.0);
    float sunA = fract(tick / 24000.0 + 0.75) * TAU;                    // 0 = noon overhead
    vec3 sunDir = vec3(-sin(sunA), cos(sunA), 0.0);                     // rises in the east (+x), sets in the west
    float dayF = clamp((cos(sunA) + 0.42) / 0.455, 0.0, 1.0);           // vanilla's sky curve

    // the layers, on the reference's timetable (tick = (hour - 6) x 1000)
    float fRise  = gskyWindow(tick, 22000.0, 2000.0,  1000.0, 1000.0);
    float fGold  = gskyWindow(tick, 21833.0, 1000.0,   500.0, 1000.0);
    float fDay   = gskyWindow(tick, 22000.0, 2000.0, 10667.0, 2000.0);
    float fSet   = gskyWindow(tick, 12000.0,  500.0,   500.0, 1000.0);
    float fPeach = gskyWindow(tick, 11500.0,  500.0,  1667.0,  500.0);
    float fNight = gskyWindow(tick, 12750.0, 1250.0,  8417.0, 1250.0);

    vec3 c = SKY_PALE * dayF;
    c = mix(c, SKY_PURPLE, fRise * clamp(0.34 * exp(-4.3 * dir.y), 0.0, 1.0));
    c = mix(c, SKY_BLUE, fDay * smoothstep(-0.10, 0.50, dir.y));
    c = mix(c, SKY_INDIGO, fSet * smoothstep(-0.55, 0.45, dir.y));
    c = 1.0 - (1.0 - c) * (1.0 - SKY_NAVY * fNight);                    // screen blend

    // the horizon is the biome's fog colour; the sky disc ends ~1.8 degrees up, so it must be fully fog by then
    c = mix(c, FogColor.rgb, 1.0 - smoothstep(0.03, 0.24, up));
    c += SKY_GOLD * fGold * gskyBand(dir, 1.0) + SKY_PEACH * fPeach * gskyBand(dir, -1.0);

    if (fNight > 0.002 && dir.y > 0.0) {
        float ca = cos(sunA), sa = sin(sunA);                           // the star sphere turns with the sun
        vec3 s = vec3(ca * dir.x + sa * dir.y, -sa * dir.x + ca * dir.y, dir.z);
        float fade = fNight * smoothstep(0.03, 0.25, up);
        c += vec3(1.0) * gskyStars(s, px) * fade;
        c += gskyMeteors(dir, t) * fade;
    }

    if (CLOUDS_ON && dir.y > 0.02) {
        vec3 cam = vec3(CameraBlockPos) - CameraOffset;
        vec2 across = vec2(-CLOUD_WIND.y, CLOUD_WIND.x);
        float height = max(CLOUD_Y - cam.y, 80.0);
        // the plane curves down a little toward the horizon (the + 0.10), so distant clouds flatten instead of smearing
        vec2 q = cam.xz + dir.xz * height / (up + 0.10);
        // the cloud pixel this ray lands on: square in the world, and the whole picture slides along the wind
        float drift = GameTime * CLOUD_PERIOD * CLOUD_PX_ALONG;
        vec2 pix = floor(vec2(dot(q, across), dot(q, CLOUD_WIND)) / CLOUD_PIXEL - vec2(0.0, drift)) + 0.5;
        vec2 grid = vec2(CLOUD_PX_ACROSS, CLOUD_PX_ALONG);
        if (gskyCloudField(pix / grid) > CLOUD_COVER) {
            vec2 centre = (across * pix.x + CLOUD_WIND * (pix.y + drift)) * CLOUD_PIXEL - cam.xz;
            float far = length(centre) / height;                         // one value per pixel, so each stays flat

            // three flat tones: open sky two pixels toward the light = the lit rim, away from it = the shaded rim
            vec2 sunFlat = vec2(dot(sunDir.xz, across), dot(sunDir.xz, CLOUD_WIND));
            vec2 toLight = floor(normalize(sunFlat + vec2(0.4, 0.55)) * 2.0 + 0.5);
            float tone = gskyCloudField((pix + toLight) / grid) <= CLOUD_COVER ? 1.0
                       : gskyCloudField((pix - toLight) / grid) <= CLOUD_COVER ? 0.0 : 0.55;

            // clouds catch the light before the ground does: warm as soon as the sky starts to brighten
            float sunUp = smoothstep(0.02, 0.30, sunDir.y);
            float moon = 1.0 - smoothstep(0.0, 0.35, dayF);
            float warm = clamp(1.0 - sunUp - moon, 0.0, 1.0);
            float east = smoothstep(-0.2, 0.2, sunDir.x);
            vec3 lightC = vec3(1.0) * sunUp + vec3(0.15, 0.20, 0.32) * moon
                        + mix(vec3(1.0, 0.72, 0.56), vec3(1.0, 0.86, 0.76), east) * warm;
            vec3 shadeC = vec3(0.76, 0.83, 0.98) * sunUp + vec3(0.06, 0.10, 0.20) * moon
                        + mix(vec3(0.56, 0.46, 0.72), vec3(0.78, 0.64, 0.88), east) * warm;
            float sunSide = dot(normalize(centre), normalize(sunDir.xz + 1e-4)) * 0.5 + 0.5;
            lightC = mix(lightC, vec3(1.0, 0.66, 0.42), warm * floor(sunSide * 3.99) / 3.0 * 0.6);
            c = mix(c, mix(shadeC, lightC, tone), (0.84 - 0.40 * moon) * (1.0 - smoothstep(2.4, 5.0, far)));
        }
    }

    float thick = 1.0 - smoothstep(110.0, 200.0, FogSkyEnd);
    c = mix(c, FogColor.rgb, linear_fog_value(length(skyPos), 0.0, FogSkyEnd) * thick * FogColor.a);
    fragColor = vec4(c, ColorModulator.a);
}
